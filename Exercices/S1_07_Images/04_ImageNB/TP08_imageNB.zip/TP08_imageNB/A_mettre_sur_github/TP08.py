import matplotlib.pyplot as plt
import matplotlib . image as img # import de la bibliotheque image
import numpy as np

##Question 1 : création d'une image noire
def image_noire(n,p):
    '''construit la matrice n*p d'une image noire'''
    img =[0]*n    #construit une liste contenant A COMPLETER
    for i in range(n): # n sera le nombre de colonne/ de lignes A COMPLETER
        img[i]=[0]*p #construit une liste contenant A COMPLETER et l'affecte à A COMPLETER
    return img   #img sera une image noire de hauteur : ??? pixels et de largeur ??? pixels  (A COMPLETER EN INDIQUANT LE NB DE PIXELS)



##Question 2 : affichage



##Question 3 : création d'images en noir et blanc rayées
def rayure_hor(n,p):
    '''construit la matrice n*p d'une image rayée horizontalement'''



    return(img)


def rayure_ver(n,p):
    '''construit la matrice n*p d'une image rayée horizontalement'''




    return(img)

##Question3bis (optionnelle) : création d'un échiquier

def echiquier(n,p):
    '''crée un motif échiquier sur une image de taille n par p'''



    return(im)


##Question 4 : modifier une image pour l'éclaircir
def eclaircir(im,k):


    return(im)



##Question 5 : modifier une image pour l'éclaircir en faisant une copie indépendante
def eclaircir2(im0,k):

    return(im)



##Question 6 : lecture d'un fichier image et appel de la fonction éclaircir



##Question 7 : lecture et affichage de l'image ciel



##Question 8 : détection de contour d'une image

def contour (im, seuil):

    return im2

##Question 9 : test



#plt.show()